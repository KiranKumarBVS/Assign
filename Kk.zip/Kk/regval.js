function validateForm() {
  var a = document.forms["myForm"]["username"].value;
  if (a == "") {
    alert("Username must be filled out");
    return false;
  }
  
   var b = document.forms["myForm"]["password"].value;
  if (b == "") {
    alert("password must be filled out");
    return false;
  }
  
   var c = document.forms["myForm"]["cpassword"].value;
  if (c == "") {
    alert("confirm your password");
    return false;
  }
  else if(c!=b)
  {	
	alert("password should match");
    return false;
	}
  
   var d = document.forms["myForm"]["name"].value;
  if (d == "") {
    alert("name must be filled out");
    return false;
  }
   var f = document.forms["myForm"]["country"].value;
  if (f==-1)                  
    { 
        alert("please select country"); 
        f.focus(); 
        return false; 
    } 
   var e = document.forms["myForm"]["role"].value;
  if (e == "") {
    alert("role is required");
    return false;
  }
 
  return true;
}